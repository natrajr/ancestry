## Library functions for Ancestry Analytics
# Spot Log process Setup file

from sqlalchemy import *
from sqlalchemy.pool import NullPool
import psycopg2
import os, sys

# the function below is used to run sql queries. Add in the username and password used to access Redshift below
def executeQuery(query):
    
    db = create_engine("postgresql+psycopg2://username:password@IP_ADDRESS:PORT/HOST", echo_pool=True, poolclass=NullPool)
    c   = db.connect()
    trans = c.begin()
    try:
        rows = c.execute(query)
        trans.commit()
        return rows
    except Exception, e:
        print e
        trans.rollback()
        sys.exit()

# the function below is used to initiate a database connection. Add in the username and password used to access Redshift belowtow 
def db_connection():
	db = create_engine("postgresql+psycopg2://username:password@IP_ADDRESS8:PORT/HOST", echo_pool = True, poolclass=NullPool) 
	return db

